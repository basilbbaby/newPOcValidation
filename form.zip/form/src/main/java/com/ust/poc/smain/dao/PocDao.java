package com.ust.poc.smain.dao;

import java.util.List;

import com.ust.poc.smain.model.Model;


public interface PocDao {

	public Model addUsers(Model model);
	public List<Model> displayUsers();
	public String deleteUsers(int id);
	public Model searchUsers(Model model);
	
}
